---
author: admin
date: 2018-11-10 00:28:38+00:00
draft: false
title: About W3 Simple
type: page
url: /zh-cn/about/
---

  
  
Hugo W3 Simple是由[Jesse Lau](https://jesselau.com/)根据W3 CSS框架设计的HUGO主题模板
