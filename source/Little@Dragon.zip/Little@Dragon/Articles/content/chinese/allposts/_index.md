---
title:              "All posts"
type:               "allposts"
---
<h2>All Posts of Hugo W3 Simple Example Site From Start</h2>



