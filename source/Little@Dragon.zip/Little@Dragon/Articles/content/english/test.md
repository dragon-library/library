---
author: admin
date: 2018-11-10 00:28:38+00:00
draft: false
title: About W3 Simple
type: page
url: /test/
---

Test page  
W3 Simple is a Hugo theme written by [Jesse Lau](https://jesselau.com/) . The main motivation for writing this theme was to provide a really minimal theme with W3 CSS included.
