---
title: "การบอกเวลา"
date: 2019-11-15T15:15:05+07:00
type: post
categories:
- Series
tags:  ["เวลา"]

draft: false
thumbnail: https://github.com/dragon-library/library/raw/master/img/desk-1148994_640.jpg
---

![enter image description here](https://github.com/dragon-library/library/raw/master/img/desk-1148994_640.jpg)

นาฬิกาเป็นเครื่องมือที่ใช้บอกเวลา บนหน้าปักนาฬิกาจะมีตัวเลข12ตัวคือ1,2,3…12 เข็มยาว เข็มสั้น และเข็มวินาที เพื่อใช้บอกเวลา

![enter image description here](https://sites.google.com/site/suthidajansong/_/rsrc/1516877462780/home/hnwy-thi3-wela/%E0%B9%80%E0%B8%A7%E0%B8%A5%E0%B8%B21.jpg)

การบอกเวลาเป็นนาฬิกาและนาที

การบอกเวลาในแต่ละวันจะเริ่มที่0นาฬิกา และสิ้นสุดที่ 24 นาฬิกา โดยแบ่งออกเป็น2ช่วงคือ ช่วงเวลากลางวันจะเริ่มตั้งแต่ 6 นาฬิกา ถึง12นาฬิกา และช่วงเวลากลางคืนจะเริ่มตั้งแต่ 18นาฬิกาถึง 6 นาฬิกา

![enter image description here](https://sites.google.com/site/suthidajansong/_/rsrc/1516877547858/home/hnwy-thi3-wela/%E0%B9%80%E0%B8%A7%E0%B8%A5%E0%B8%B22.jpg)

การเขียนบอกเวลาโดยใช้จุดและการอ่าน

การเขียนบอกเวลานิยมใช้จุด (.) คั่นระหว่างตัวเลขบอกเวลาเป็นนาฬิกากับนาที และใช้อักษรย่อ น. แทนคำว่านาฬิกา

![enter image description here](https://sites.google.com/site/suthidajansong/_/rsrc/1516877600955/home/hnwy-thi3-wela/%E0%B9%80%E0%B8%A7%E0%B8%A5%E0%B8%B23.jpg)

### หน่วยของเวลาที่ควรทราบ



|หน่วย	|ขนาด     |
|:-----:|----------|
|นาโนวินาที|1/1,000,000,000  วินาที|
|ไมโครวินาที|1/1,000,000  วินาที|
|มิลลิวินาที|1/1,000  วินาที|
|วินาที|	หน่วยฐานในระบบเอสไอ|
|นาที|	60 วินาที|
|ชั่วโมง|	60 นาที|
|วัน|	24 ชั่วโมง|
|สัปดาห์|	7 วัน|
|ปักษ์|	14 หรือ 15 วัน; 2 สัปดาห์|
|เดือน|	28 ถึง 31 วัน|
|ไตรมาส|	3 เดือน|
|ปี (ปีปฏิทิน)|	12 เดือน|
|ปีสุริยคติ|	365.24219 วัน (โดยเฉลี่ย)|
|ทศวรรษ|	10 ปี|
|ศตวรรษ|	100 ปี|
|สหัสวรรษ|	1,000 ปี|
|ทศสหัสวรรษ|	10,000 ปี|


Reference :
- [https://th.wikipedia.org/wiki/%E0%B9%80%E0%B8%A7%E0%B8%A5%E0%B8%B2](https://th.wikipedia.org/wiki/%E0%B9%80%E0%B8%A7%E0%B8%A5%E0%B8%B2)
- [https://mgronline.com/science/detail/9530000028451](https://mgronline.com/science/detail/9530000028451)
- [https://www.sanook.com/campus/926492/](https://www.sanook.com/campus/926492/)

ข้อมูล
- [What is the time? บอกเวลาภาษาอังกฤษ](https://www.dailyenglish.in.th/whats-the-time/)